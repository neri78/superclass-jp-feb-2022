'use strict';
// UI部分
const identityField = document.getElementById('identity');
const initButton = document.getElementById('init');
const dialForm = document.getElementById('dialForm');
const toField = document.getElementById('to');
const callButton = document.getElementById('call');
const connectButton = document.getElementById('connect');
const disconnectButton = document.getElementById('disconnect');

let device;
let activeCall;

// 初期化ボタンをクリックした際にアクセストークンを取得し、Twilio.Deviceを初期化する。
initButton.addEventListener('click', async() => {

    const identity = identityField.value;
    // トークンを取得
    let response = await fetch(`/voice-token?identity=${identity}`, {
        method: 'GET',
        headers: {
            'Content-Type' : 'application/json'
        }
    });
    let {token}  = await response.json();
    
    // トークンを用いて初期化
    device = new Twilio.Device(token);
    device.register();

    // Twilio Clientの準備ができた段階で発信ボタンを有効化
    device.on('registered', () => {
        identityField.disabled = true;
        callButton.disabled = false;
        connectButton.disabled = true;
        initButton.disabled = true;
    });

    // Twilio Clientの着信時に応答ボタンを有効化
    device.on('incoming', (incomingCall) => {
        callButton.disabled = true;
        connectButton.disabled = false;

        activeCall = incomingCall;
        // 着信通話が完了した時点で、原状復帰
        activeCall.on('disconnect', callDisconnected);

    });

});

// 発信ボタンをクリックすると、Twilio.Deviceを用いて通話を開始
dialForm.addEventListener('submit', async (event) => {

    event.preventDefault();

    // クリックされたボタンのidを取得
    const submitId = event.submitter.id;

    // 発信ボタンがクリックされた場合はTwiML Appに対して入力された番号に発信してもらう。
    if (submitId === 'call') {
        const number = toField.value;
        callButton.disabled = true;
        // 番号を指定して発信
        activeCall = await device.connect({ 
                            params: { To: number } });
        // 発信通話が完了した時点で、原状復帰
        activeCall.on('disconnect', callDisconnected);

        disconnectButton.disabled = false;
    }

    // 終了ボタンがクリックされた場合は接続を終了する。
    else if (submitId === 'disconnect') {
        // 全ての接続（通話）を終了
        device.disconnectAll();
        disconnectButton.disabled = true;
        connectButton.disabled = true;
        callButton.disabled = false; 
        activeCall = null;
    }

    // 応答ボタンがクリックされている場合
    else if (submitId === 'connect') {
        // 通話を取得し、応答
        if (activeCall)
            activeCall.accept();
        connectButton.disabled = true;
        disconnectButton.disabled = false;
    }
});

// 通話が終了した際に原状復帰を行うメソッド
function callDisconnected(){
    disconnectButton.disabled = true;
    connectButton.disabled = true;
    callButton.disabled = false; 
    activeCall = null;
}
